BEGIN TRANSACTION;

CREATE TABLE #table1 (
    Col_1 VARCHAR(255),
    Col_2 INT,
    Col_3 VARCHAR(255)
);

WITH report AS (
  SELECT 
    ext_table1.Name
    , ext_table1.id
  FROM ext_table1
  INNER JOIN ext_table2 ON ext_table1.id = ext_table2.id
  WHERE ext_table1.Name = 'yoshida'
)
INSERT INTO #table1 (Col_1, Col_2)
SELECT 
  Name
  , id
FROM report;

SELECT * FROM #table1 ;

IF @@ERROR <> 0
    ROLLBACK TRANSACTION;
ELSE
    COMMIT TRANSACTION;
